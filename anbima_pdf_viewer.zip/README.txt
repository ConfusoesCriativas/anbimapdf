ANBIMA PDF Viewer

Viewer minimalista baseado em PDF.js, preparado para GitHub Pages e Genially.

ESTRUTURA SUGERIDA

anbimapdf/
  viewer/
    index.html
  unidade1/
    A1-1Exploracao.pdf
  unidade2/
    ...
  unidade3/
    ...

PUBLICAÇÃO

1. Crie a pasta viewer no repositório anbimapdf.
2. Envie o index.html para essa pasta.
3. Ative o GitHub Pages para a branch main, pasta / (root).
4. Aguarde a publicação.

URL do viewer:
https://confusoescriativas.github.io/anbimapdf/viewer/

EXEMPLO

https://confusoescriativas.github.io/anbimapdf/viewer/?file=../unidade1/A1-1Exploracao.pdf

QUALIDADE

Padrão:
quality=1.5

Mais nítido:
quality=2

Exemplo:
https://confusoescriativas.github.io/anbimapdf/viewer/?file=../unidade1/A1-1Exploracao.pdf&quality=2

IFRAME PARA GENIALLY

<iframe
  src="https://confusoescriativas.github.io/anbimapdf/viewer/?file=../unidade1/A1-1Exploracao.pdf&quality=1.5"
  width="100%"
  height="900"
  style="border:0; background:#fff;"
  allowfullscreen>
</iframe>

FÓRMULA-BASE PARA GOOGLE SHEETS

Supondo:
A2 = número da unidade
C2 = nome completo do PDF, incluindo .pdf

URL do viewer:

="https://confusoescriativas.github.io/anbimapdf/viewer/?file=../unidade"&A2&"/"&ARRUMAR(LIMPAR(C2))&"&quality=1.5"

Depois, se essa URL estiver em E2, o iframe pode ser:

="<iframe src="""&E2&""" width=""100%"" height=""900"" style=""border:0; background:#ffffff;"" allowfullscreen></iframe>"
